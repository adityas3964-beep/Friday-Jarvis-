# F.R.I.D.A.Y — native Android voice assistant (Kotlin + Jetpack Compose)

Renamed from JARVIS. The application ID / package (`com.jarvis.assistant`) is **unchanged on purpose**, so it installs over the old build and existing settings carry over. Only visible branding changed.

> **Honest status:** this source has **not been compiled or run**. The authoring sandbox had no Gradle, no Android SDK and no network. The first GitHub Actions build is the first real compile. If it fails, open the failed step and send me the `error:` lines.

## Versions (read from the project)
Single module `:app` · minSdk 26 · compileSdk/targetSdk 34 · AGP 8.5.2 · Gradle 8.7 · Kotlin 1.9.24 · Compose compiler 1.5.14 · JDK 17 · no product flavors · no Gradle wrapper included.

## Build
- **GitHub:** push the *contents* of this folder (not the ZIP) to a repo → **Actions → Build FRIDAY debug APK → Run workflow** → when green, open the run → **Artifacts → friday-debug-apk** → unzip → install `app-debug.apk`.
- **Local:** `gradle :app:assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34). Optional tests: `gradle :app:testDebugUnitTest`. Run `gradle wrapper --gradle-version 8.7` once if you want a wrapper.
- Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Speech recognition modes (SETTINGS tab)
| Mode | Engine | Needs |
|---|---|---|
| Online | Android `SpeechRecognizer` (usually Google) | Internet on most phones; free, provider limits apply; language en-IN or hi-IN |
| Offline | Vosk | A Vosk model downloaded once (SETTINGS → Voice models, ~40-50 MB each) |
| Automatic | Online first, Vosk on failure/no internet | Offline model optional but needed for fallback; after an online failure it stays offline for 60 s (no flapping); if neither is usable it says so |

The wake word is always local (Vosk), so it needs the English model even in Online mode.

## Wake word
Toggle, custom phrase (default `hey friday`), live status, and a **Test wake word** button. It is *not* a dedicated wake-word engine: Vosk's normal recognition text is matched against the phrase, so any phrase can be saved but is only detected if the model can recognise its words — use the test. Microphone stays live while waiting (battery cost; some phones block background mic). PUSH TO TALK always works.

## Voice (TTS)
Android TextToSpeech only (free, no account). Pick a voice from the installed list, speed, pitch, **Test voice**. Hindi: install Hindi (India) voice data in Android Settings → Text-to-speech (button provided). Android does not report voice gender, so the app cannot promise a "female" voice — try voices with Test voice. No cloud TTS is included.

## Hinglish
`Normalizer` has safe aliases (e.g. "you tube") and context aliases (e.g. "you do", "what's up", "coal") applied only next to command words. New commands: volume up/down/mute, torch on/off. Recognition accuracy still depends on the engine.

## Limits
Torch/volume use standard Android APIs (untested on devices). Wi-Fi/Bluetooth cannot be toggled by apps on modern Android; the settings screen opens instead. See PROGRESS.md for the verified / unverified list.
