package com.jarvis.assistant.command

/** Pure-Kotlin parser (no Android dependencies) so it can be unit-tested on the JVM. */
object CommandParser {
    private val YES = setOf("haan", "han", "ha", "yes", "yeah", "ok", "okay", "confirm", "bhej do", "bhejo", "kar do",
        "send", "sure", "theek hai", "bilkul", "send it", "yes send")
    private val NO = setOf("nahi", "nahin", "no", "cancel", "mat bhej", "mat bhejo", "mat karo", "ruko", "nope")

    private val R_WA_HINDI = Regex("^(\\S+) ko (?:whatsapp (?:par|pe|per|me|mein) )?(?:whatsapp|message|msg|sandesh) (?:(?:bhej\\w*|send|kar\\w*) )?(.+)$")
    private val R_WA_EN = Regex("^(?:send )?(?:a )?(?:whatsapp )?(?:message|msg|sandesh) (?:to )?(\\S+) (?:saying |that |ki )?(.+)$")
    private val R_VERB_ONLY = Regex("^(bhej\\w*|send|kar\\w*)$")

    private val Y1 = Regex("^(?:search|play|dhundh\\w*|dhoondh\\w*|chala\\w*|laga\\w*) (?:for )?(.+?) (?:on |par |pe |per |me |mein )?youtube(?: .*)?$")
    private val Y3 = Regex("^(.+?) youtube (?:par|pe|per|me|mein|on) (?:search|play|chala\\w*|laga\\w*|dhundh\\w*).*$")
    private val Y2 = Regex("^youtube (?:par |pe |per |me |mein |on )?(?:search |play |dhundh\\w* )?(.+?)(?: (?:search|play|chala\\w*|laga\\w*|dhundh\\w*))?(?: (?:kar|karo|do|de))*$")

    private val S1 = Regex("^(?:search|google|dhundh\\w*|dhoondh\\w*)(?: for)? (.+?)(?: (?:kar|karo|do|de))*$")
    private val S2 = Regex("^(.+?) (?:search|google)(?: (?:kar|karo|do))*$")

    private val O1 = Regex("^(?:open|launch|start) (.+?)(?: (?:kar|karo|do|de))*$")
    private val O2 = Regex("^(.+?) (?:khol\\w*|chalu|chalao|open|start)(?: (?:kar|karo|do|de|dena))*$")

    private val OPEN_VERBS = Regex("^(khol\\w*|open|chalu|chalao|start|kar|karo|do|de)( (kar|karo|do|de))*$")

    private fun has(t: String, vararg words: String) = words.any { " $t ".contains(" $it ") }

    fun parse(raw: String): Cmd {
        if (raw.isBlank()) return Cmd.Unknown(raw)
        val t = Normalizer.normalize(raw)
        if (t.isBlank()) return Cmd.Greeting
        if (t in YES) return Cmd.Yes
        if (t in NO) return Cmd.No
        if (t == "band karo" || has(t, "stop", "stop listening", "bye", "good bye", "alvida", "band ho ja")) return Cmd.Stop

        // WhatsApp message
        if (has(t, "message", "msg", "sandesh")) {
            val m = R_WA_HINDI.find(t) ?: R_WA_EN.find(t)
            if (m != null) {
                val text = m.groupValues[2].trim()
                if (R_VERB_ONLY.matches(text)) return Cmd.MissingArg("Kya message bhejna hai?")
                return Cmd.WhatsApp(m.groupValues[1], text)
            }
            return Cmd.MissingArg("Kisko aur kya message bhejna hai?")
        }

        if (has(t, "lock") || t.contains("screen band") || t.contains("phone band")) return Cmd.Lock
        if (has(t, "next reel", "next video", "next short", "swipe up", "reel badlo", "agli reel")) return Cmd.Swipe(true)
        if (has(t, "previous reel", "previous video", "pichli reel", "swipe down")) return Cmd.Swipe(false)
        if (has(t, "go home", "home screen", "home jao")) return Cmd.Home
        if (has(t, "go back", "back jao", "peeche jao", "piche jao", "back kar")) return Cmd.Back

        // Volume (before the settings block so "volume badhao" changes volume while "volume settings kholo" opens settings)
        if (has(t, "volume", "awaaz", "sound") && !has(t, "settings", "setting", "khol", "kholo", "open")) {
            when {
                has(t, "mute", "silent") -> return Cmd.Volume(0)
                has(t, "badhao", "badha", "badhana", "increase", "up", "zyada", "tez", "louder") -> return Cmd.Volume(1)
                has(t, "kam", "ghatao", "ghata", "ghatana", "decrease", "down", "low", "dheere", "halka") -> return Cmd.Volume(-1)
            }
        }

        // Torch / flashlight
        if (has(t, "torch", "flashlight")) {
            return when {
                has(t, "off", "band", "bujhao", "bandh") -> Cmd.Torch(false)
                has(t, "on", "chalu", "jalao", "chalao", "start") -> Cmd.Torch(true)
                else -> Cmd.MissingArg("Torch on karun ya off?")
            }
        }

        // Settings screens
        val kind = when {
            has(t, "wifi", "wi fi") -> "wifi"
            has(t, "bluetooth") -> "bluetooth"
            has(t, "display", "brightness") -> "display"
            has(t, "sound", "volume", "awaaz") -> "sound"
            has(t, "accessibility") -> "accessibility"
            else -> null
        }
        if (kind != null && has(t, "khol", "kholo", "open", "settings", "setting", "on", "off", "chalu", "band")) {
            return Cmd.OpenSettings(kind)
        }

        // YouTube
        if (has(t, "youtube")) {
            Y1.find(t)?.let { return Cmd.YouTubeSearch(it.groupValues[1].trim()) }
            Y3.find(t)?.let { return Cmd.YouTubeSearch(it.groupValues[1].trim()) }
            Y2.find(t)?.let {
                val q = it.groupValues[1].trim()
                if (!OPEN_VERBS.matches(q)) return Cmd.YouTubeSearch(q)
            }
        }

        // Web search
        if (t in setOf("search", "google", "dhundho", "search karo")) return Cmd.MissingArg("Kya search karna hai?")
        S1.find(t)?.let {
            val q = it.groupValues[1].trim()
            if (!OPEN_VERBS.matches(q)) return Cmd.WebSearch(q)
        }
        S2.find(t)?.let {
            val q = it.groupValues[1].trim()
            if (!OPEN_VERBS.matches(q)) return Cmd.WebSearch(q)
        }

        // Identity
        if (has(t, "tumhara naam", "tera naam", "aapka naam", "your name", "who are you", "tum kaun ho", "aap kaun ho", "tu kaun hai")) return Cmd.AskName
        if (has(t, "mera naam", "my name", "main kaun hoon")) return Cmd.AskUserName

        // Time / date
        if (has(t, "date", "tarikh", "tareekh", "what day", "kaun sa din")) return Cmd.TellDate
        if (has(t, "time", "samay", "baje", "waqt")) return Cmd.TellTime

        // Open app
        (O1.find(t) ?: O2.find(t))?.let {
            val name = it.groupValues[1].trim().removeSuffix(" app").trim()
            if (name.isNotEmpty()) return Cmd.OpenApp(name)
        }

        if (has(t, "thanks", "thank you", "thank", "shukriya", "dhanyavad")) return Cmd.Thanks
        if (has(t, "kaise ho", "how are you", "kya haal", "kaisa hai")) return Cmd.HowAreYou
        if (has(t, "hello", "hi", "namaste", "namaskar") || t == "jarvis") return Cmd.Greeting

        return if (t.split(" ").size >= 2) Cmd.Chat(raw.trim()) else Cmd.Unknown(raw)
    }
}
