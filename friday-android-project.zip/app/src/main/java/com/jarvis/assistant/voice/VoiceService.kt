package com.jarvis.assistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.command.CommandDispatcher
import com.jarvis.assistant.command.CommandParser
import com.jarvis.assistant.command.CommandResult
import com.jarvis.assistant.command.WakeMatcher
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.HistoryItem
import com.jarvis.assistant.data.Prefs
import com.jarvis.assistant.data.RecogMode
import com.jarvis.assistant.data.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.android.RecognitionListener
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Voice session: WAKE WORD -> GREETING -> LISTEN -> RECOGNIZE -> UNDERSTAND -> CONFIRM -> EXECUTE -> SPEAK -> RESUME.
 * Wake-word detection is always local (Vosk). Commands use Online (Android SpeechRecognizer), Offline (Vosk) or Automatic.
 * Exactly one microphone session exists at a time; the mic is released before every spoken reply.
 */
class VoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: JarvisApp
    private lateinit var engine: VoskEngine
    private lateinit var online: OnlineRecognizer
    private lateinit var tts: Tts
    private lateinit var dispatcher: CommandDispatcher

    private var running = false
    private var wakeMode = true
    private var testing = false
    private var cmdModel: Model? = null
    private var wakeModel: Model? = null
    private var sessionId = 0
    private val handled = AtomicBoolean(false)
    private var lastPartial = ""
    private var onlineBlockedUntil = 0L      // after an online failure, AUTO mode stays offline for a minute (no flapping)
    private val turns = ArrayDeque<Pair<String, String>>()

    companion object {
        const val ACTION_START = "com.jarvis.assistant.START"
        const val ACTION_PTT = "com.jarvis.assistant.PTT"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val ACTION_TEST_WAKE = "com.jarvis.assistant.TEST_WAKE"
        private const val CHANNEL = "jarvis_voice"   // id kept so existing installs keep their channel settings
        private const val NOTIF_ID = 42
        private const val ONLINE_COOLDOWN_MS = 60_000L

        fun start(ctx: Context, pushToTalk: Boolean) {
            val i = Intent(ctx, VoiceService::class.java).setAction(if (pushToTalk) ACTION_PTT else ACTION_START)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun testWake(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceService::class.java).setAction(ACTION_TEST_WAKE))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onCreate() {
        super.onCreate()
        app = application as JarvisApp
        engine = VoskEngine(this)
        online = OnlineRecognizer(this)
        tts = Tts(this)
        dispatcher = CommandDispatcher(this, app)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "FRIDAY voice session", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> shutdown(VoiceState.STOPPED)
            ACTION_PTT -> begin(pushToTalk = true)
            ACTION_TEST_WAKE -> beginWakeTest()
            else -> begin(pushToTalk = false)
        }
        return START_NOT_STICKY   // a mic foreground service cannot be silently restarted from the background on Android 14+
    }

    override fun onDestroy() {
        running = false
        online.cancel()
        engine.release()
        tts.shutdown()
        scope.cancel()
        if (AssistantState.state.value != VoiceState.ERROR) AssistantState.state.value = VoiceState.STOPPED
        super.onDestroy()
    }

    private fun prefs(): Prefs = app.settings.prefs.value
    private fun ttsOpts(p: Prefs) = TtsOptions(p.ttsVoice, p.ttsRate, p.ttsPitch)

    // ---- lifecycle ----

    private fun begin(pushToTalk: Boolean) {
        val ptt = pushToTalk || !prefs().wakeEnabled   // wake word switched off in Settings: never listen for it
        if (running) {
            // Never open a second mic session; only allow switching from wake-wait to push-to-talk.
            if (ptt && !testing && AssistantState.state.value == VoiceState.WAITING_FOR_WAKE_WORD) {
                sessionId++
                engine.stop()
                listenCommand()
            }
            return
        }
        if (!startForegroundSafely()) return
        running = true
        testing = false
        wakeMode = !ptt
        AssistantState.error.value = null
        AssistantState.heard.value = ""
        AssistantState.state.value = VoiceState.INITIALIZING
        scope.launch {
            val p = prefs()
            val problem = withContext(Dispatchers.IO) { loadModels(p) }
            if (!running) return@launch
            if (problem != null) { fail(problem); return@launch }
            if (wakeMode) enterWake() else listenCommand()
        }
    }

    /** Loads only the offline models the current settings need. Returns an error message, or null if ready. Blocking. */
    private fun loadModels(p: Prefs): String? {
        try {
            wakeModel = when {
                !wakeMode -> null
                p.recogLang == "en" -> engine.model("en")
                else -> engine.model("en") ?: engine.model(p.recogLang)
            }
            cmdModel = if (p.recogMode == RecogMode.ONLINE) null else engine.model(p.recogLang)
        } catch (t: Throwable) {
            return "Voice model load nahi hua: ${t.message}"
        }
        if (wakeMode && wakeModel == null)
            return "Wake word ke liye offline voice model chahiye. Settings > Voice models se download kijiye, ya PUSH TO TALK use kijiye."
        return when (p.recogMode) {
            RecogMode.OFFLINE ->
                if (cmdModel == null) "Offline mode ke liye voice model (${p.recogLang}) nahi mila. Settings > Voice models se download kijiye." else null
            RecogMode.ONLINE ->
                if (!OnlineRecognizer.isAvailable(this)) "Is phone par online speech recognition service nahi hai. Offline ya Automatic mode chuniye." else null
            RecogMode.AUTO ->
                if (cmdModel == null && !OnlineRecognizer.isAvailable(this))
                    "Na online recognition available hai na offline model installed hai. Settings > Voice models se model download kijiye." else null
        }
    }

    /** Foreground service must start within seconds of startForegroundService(); returns false (and stops) on failure. */
    private fun startForegroundSafely(): Boolean {
        return try { startFg(); true } catch (e: Exception) {
            AssistantState.error.value = "Foreground service start nahi hua: ${e.message}"
            AssistantState.state.value = VoiceState.ERROR
            stopSelf()
            false
        }
    }

    private fun startFg() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("FRIDAY microphone active")
            .setContentText("Sun raha hoon. Band karne ke liye Stop dabaiye.")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, n)
    }

    private fun shutdown(finalState: VoiceState) {
        running = false
        testing = false
        sessionId++
        engine.stop()
        online.cancel()
        tts.stop()
        dispatcher.confirmation.clear()
        AssistantState.state.value = finalState
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(message: String) {
        AssistantState.error.value = message
        shutdown(VoiceState.ERROR)
    }

    // ---- wake word ----

    private fun parseJson(h: String?, key: String): String =
        try { JSONObject(h ?: "{}").optString(key, "").trim() } catch (e: Exception) { "" }

    private fun enterWake() {
        if (!running) return
        val m = wakeModel ?: return fail("Wake model load nahi hua")
        AssistantState.state.value = VoiceState.WAITING_FOR_WAKE_WORD
        val id = ++sessionId
        val fired = AtomicBoolean(false)
        fun check(text: String) {
            if (id != sessionId || text.isEmpty()) return
            if (WakeMatcher.matches(text, prefs().wakePhrase) && fired.compareAndSet(false, true)) {
                engine.stop()
                onWake()
            }
        }
        try {
            engine.listen(m, 0, object : RecognitionListener {
                override fun onPartialResult(h: String?) = check(parseJson(h, "partial"))
                override fun onResult(h: String?) = check(parseJson(h, "text"))
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) { if (id == sessionId) fail("Mic error: ${e?.message}") }
                override fun onTimeout() {}
            })
        } catch (e: Exception) { fail("Microphone shuru nahi hua: ${e.message}") }
    }

    /** Settings > Test wake word: listens for ten seconds and reports whether the phrase was heard. */
    private fun beginWakeTest() {
        if (running) {
            AssistantState.wakeTest.value = "Pehle chalta hua session STOP kijiye, phir test kijiye."
            return
        }
        if (!startForegroundSafely()) { AssistantState.wakeTest.value = "Test shuru nahi hua."; return }
        running = true
        testing = true
        wakeMode = true
        val p = prefs()
        AssistantState.error.value = null
        AssistantState.heard.value = ""
        AssistantState.state.value = VoiceState.INITIALIZING
        AssistantState.wakeTest.value = "Model load ho raha hai..."
        scope.launch {
            val m = withContext(Dispatchers.IO) {
                try { if (p.recogLang == "en") engine.model("en") else (engine.model("en") ?: engine.model(p.recogLang)) }
                catch (t: Throwable) { null }
            }
            if (!running) return@launch
            if (m == null) { finishWakeTest("Offline voice model nahi mila. Pehle Voice models se download kijiye."); return@launch }
            runWakeTest(m, p.wakePhrase)
        }
    }

    private fun runWakeTest(m: Model, phrase: String) {
        AssistantState.state.value = VoiceState.WAITING_FOR_WAKE_WORD
        AssistantState.wakeTest.value = "Ab boliye: \"$phrase\" (10 second)"
        val id = ++sessionId
        val finished = AtomicBoolean(false)
        fun check(text: String) {
            if (id != sessionId || text.isEmpty()) return
            AssistantState.heard.value = text
            if (WakeMatcher.matches(text, phrase) && finished.compareAndSet(false, true))
                finishWakeTest("DETECTED: wake phrase suna gaya (\"$text\").")
        }
        try {
            engine.listen(m, 10000, object : RecognitionListener {
                override fun onPartialResult(h: String?) = check(parseJson(h, "partial"))
                override fun onResult(h: String?) = check(parseJson(h, "text"))
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) {
                    if (id == sessionId && finished.compareAndSet(false, true)) finishWakeTest("Mic error: ${e?.message}")
                }
                override fun onTimeout() {
                    if (id != sessionId || !finished.compareAndSet(false, true)) return
                    val heard = AssistantState.heard.value
                    finishWakeTest(
                        if (heard.isBlank()) "NOT DETECTED: kuch suna nahi gaya. Mic aur model check kijiye."
                        else "NOT DETECTED: model ne \"$heard\" suna. Shayad ye phrase model pehchaan nahi pa raha; doosra phrase try kijiye."
                    )
                }
            })
        } catch (e: Exception) { finishWakeTest("Microphone shuru nahi hua: ${e.message}") }
    }

    private fun finishWakeTest(message: String) {
        AssistantState.wakeTest.value = message
        shutdown(VoiceState.STOPPED)
    }

    private fun onWake() {
        if (!running) return
        val p = prefs()
        val who = p.userName.ifBlank { "sir" }
        val greeting = p.greeting.ifBlank { "Haan $who, boliye. Main sun raha hoon." }
        AssistantState.response.value = greeting
        AssistantState.responseSource.value = "LOCAL"
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(greeting, p.ttsLang, ttsOpts(p)) { if (running) listenCommand() }
    }

    // ---- command recognition (Online / Offline / Automatic) ----

    private fun listenCommand() {
        if (!running) return
        AssistantState.state.value =
            if (dispatcher.confirmation.hasPending) VoiceState.AWAITING_CONFIRMATION else VoiceState.LISTENING
        AssistantState.heard.value = ""
        lastPartial = ""
        handled.set(false)
        val p = prefs()
        val useOnline = when (p.recogMode) {
            RecogMode.ONLINE -> true
            RecogMode.OFFLINE -> false
            RecogMode.AUTO -> System.currentTimeMillis() >= onlineBlockedUntil &&
                OnlineRecognizer.hasInternet(this) && OnlineRecognizer.isAvailable(this)
        }
        when {
            useOnline -> listenOnline(p, fallbackAllowed = p.recogMode == RecogMode.AUTO && cmdModel != null)
            cmdModel != null -> listenOffline(if (p.recogMode == RecogMode.AUTO) "OFFLINE (AUTO)" else "OFFLINE")
            else -> recognitionUnavailable("Internet nahi hai aur offline voice model bhi installed nahi hai. Settings > Voice models se model download kijiye.")
        }
    }

    private fun listenOnline(p: Prefs, fallbackAllowed: Boolean) {
        engine.stop()   // release the Vosk microphone before SpeechRecognizer opens it
        val id = ++sessionId
        AssistantState.recogEngine.value = "ONLINE"
        val tag = if (p.recogLang == "hi") "hi-IN" else "en-IN"
        online.start(tag, object : OnlineRecognizer.Listener {
            override fun onPartial(text: String) {
                if (id != sessionId) return
                lastPartial = text
                AssistantState.heard.value = text
            }
            override fun onFinal(text: String) { if (id == sessionId) handleText(text) }
            override fun onNoSpeech() {
                if (id != sessionId) return
                if (lastPartial.isNotEmpty()) handleText(lastPartial)
                else { dispatcher.confirmation.clear(); resume() }
            }
            override fun onFailure(kind: OnlineFailure, message: String) {
                if (id != sessionId) return
                if (kind == OnlineFailure.SERVICE_UNAVAILABLE) onlineBlockedUntil = System.currentTimeMillis() + ONLINE_COOLDOWN_MS
                if (fallbackAllowed && kind == OnlineFailure.SERVICE_UNAVAILABLE && cmdModel != null) {
                    // One fallback per utterance; the offline attempt never switches back to online.
                    AssistantState.error.value = "Online recognition fail ($message); offline engine use ho raha hai."
                    listenOffline("OFFLINE (FALLBACK)")
                } else recognitionUnavailable(message)
            }
        })
    }

    private fun listenOffline(label: String) {
        val m = cmdModel ?: return recognitionUnavailable("Offline voice model load nahi hua.")
        online.cancel()
        AssistantState.recogEngine.value = label
        val id = ++sessionId
        try {
            engine.listen(m, 10000, object : RecognitionListener {
                override fun onPartialResult(h: String?) {
                    if (id != sessionId) return
                    val t = parseJson(h, "partial")
                    if (t.isNotEmpty()) { lastPartial = t; AssistantState.heard.value = t }
                }
                override fun onResult(h: String?) { if (id == sessionId) handleText(parseJson(h, "text")) }
                override fun onFinalResult(h: String?) { if (id == sessionId) handleText(parseJson(h, "text")) }
                override fun onError(e: Exception?) { if (id == sessionId) fail("Mic error: ${e?.message}") }
                override fun onTimeout() {
                    if (id != sessionId) return
                    if (lastPartial.isNotEmpty()) handleText(lastPartial)
                    else { dispatcher.confirmation.clear(); resume() }
                }
            })
        } catch (e: Exception) { fail("Microphone shuru nahi hua: ${e.message}") }
    }

    /** Recognition cannot run right now: say so, then return to wake-wait (or end a push-to-talk session). No retry loop. */
    private fun recognitionUnavailable(message: String) {
        if (!running) return
        sessionId++
        engine.stop()
        online.cancel()
        val p = prefs()
        AssistantState.error.value = message
        AssistantState.response.value = message
        AssistantState.responseSource.value = "LOCAL"
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(message, p.ttsLang, ttsOpts(p)) { if (running) resume() }
    }

    private fun handleText(text: String) {
        if (text.isEmpty() || !handled.compareAndSet(false, true)) return   // never execute a command twice
        sessionId++
        engine.stop()
        online.cancel()
        AssistantState.state.value = VoiceState.PROCESSING
        AssistantState.heard.value = text
        scope.launch {
            val cmd = CommandParser.parse(text)
            val result = try {
                dispatcher.dispatch(cmd, turns.toList())
            } catch (t: Throwable) {
                CommandResult(false, "Kuch gadbad ho gayi: ${t.message}")
            }
            if (!running) return@launch
            app.history.add(HistoryItem(System.currentTimeMillis(), text, result.message, result.source, result.success))
            turns.addLast(text to result.message)
            while (turns.size > 4) turns.removeFirst()
            reply(result)
        }
    }

    private fun reply(r: CommandResult) {
        val p = prefs()
        AssistantState.response.value = r.message
        AssistantState.responseSource.value = r.source
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(r.message, p.ttsLang, ttsOpts(p)) {
            if (!running) return@speak
            when {
                r.stopSession -> shutdown(VoiceState.STOPPED)
                dispatcher.confirmation.hasPending -> listenCommand()   // wait for yes/no
                else -> resume()
            }
        }
    }

    /** SPEAK -> RESUME LISTENING. Push-to-talk sessions end after one command. */
    private fun resume() {
        if (!running) return
        if (wakeMode) enterWake() else shutdown(VoiceState.STOPPED)
    }
}
