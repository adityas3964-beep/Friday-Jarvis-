package com.jarvis.assistant.voice

import android.content.Context
import com.jarvis.assistant.data.AssistantState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads a free Vosk model zip from alphacephei.com and unpacks it into the app's model directory. */
object ModelDownloader {
    val urls = mapOf(
        "en" to "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip",
        "hi" to "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
    )

    suspend fun download(context: Context, lang: String) = withContext(Dispatchers.IO) {
        val url = urls[lang] ?: return@withContext
        AssistantState.downloadError.value = null
        AssistantState.downloadProgress.value = lang to 0
        val tmp = File(context.cacheDir, "model-$lang.zip")
        val target = VoskEngine.modelDir(context, lang)
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
            }
            if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read: Int
                    var sum = 0L
                    while (input.read(buf).also { read = it } >= 0) {
                        out.write(buf, 0, read)
                        sum += read
                        if (total > 0) AssistantState.downloadProgress.value = lang to (sum * 90 / total).toInt()
                    }
                }
            }
            AssistantState.downloadProgress.value = lang to 92
            if (target.exists()) target.deleteRecursively()
            target.mkdirs()
            unzipStripTop(tmp, target)
            if (!File(target, "am").isDirectory) throw java.io.IOException("Unzipped model has no 'am' folder")
            AssistantState.downloadProgress.value = lang to 100
        } catch (e: Exception) {
            target.deleteRecursively()
            AssistantState.downloadError.value = "Download fail ($lang): ${e.message}"
        } finally {
            tmp.delete()
            AssistantState.downloadProgress.value = null
        }
    }

    private fun unzipStripTop(zip: File, dest: File) {
        val destPath = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                val name = entry.name.substringAfter('/', "")   // drop the top-level folder
                if (name.isNotEmpty()) {
                    val out = File(dest, name)
                    if (!out.canonicalPath.startsWith(destPath)) throw java.io.IOException("Bad zip entry")
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { zin.copyTo(it) }
                    }
                }
                entry = zin.nextEntry
            }
        }
    }
}
