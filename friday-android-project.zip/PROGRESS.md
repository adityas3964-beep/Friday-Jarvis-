# PROGRESS (FRIDAY upgrade)

## Verified (what was actually run)
- XML resources and manifest parse as well-formed XML (Python).
- Workflow YAML parses (PyYAML); referenced paths match the file tree.
- Normalizer alias rules and the new parser branches, checked through a **Python port** of the logic (not the Kotlin itself): context aliases leave "what do you do" / "I love you too" / "coal mining" alone and fix "open you do" / "YouTube coal"; volume/torch/Hinglish examples parse as intended. Devanagari word mapping was NOT covered by that check.
- Crude brace/parenthesis balance check on every .kt file.

## NOT verified
- Kotlin compilation, unit tests (`CommandParserTest`), Gradle build, APK generation, GitHub Actions run, anything on a device (recognition modes, fallback, TTS voice list/test, wake word + test, torch, volume, credits layout).

## Implemented, untested
Rename to FRIDAY (visible text, notification, launcher label, AI prompt, default wake phrase with migration of the old `hey jarvis` default) · Online/Offline/Automatic modes with persistence · context-aware Hinglish aliases, volume/torch commands · TTS voice/speed/pitch/Test voice/voice-data buttons · wake enable/phrase/status/test · Settings reorganised (SETTINGS tab) with About/Credits at the very bottom.

## Not implemented
- Cloud TTS (needs account/key; nothing permanently free and key-less was added; no key is bundled).
- Dedicated wake-word engine (phrase matching on Vosk text instead).
- Gradle wrapper jar (cannot be generated offline).
- Guaranteed female-sounding voice (Android exposes no gender).

## Intentionally unchanged internal names
Package `com.jarvis.assistant`, class names (`JarvisApp`, …), `jarvis_*` prefs/keystore/channel ids — kept for install and data compatibility.
